"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function MutationObserverDemo() {
  const [count, setCount] = useState(0)
  const sourceRef = useRef<HTMLDivElement>(null)
  const targetRef = useRef<HTMLDivElement>(null)

  // Increment the counter
  const increment = () => {
    setCount((prev) => prev + 1)
  }

  // Decrement the counter
  const decrement = () => {
    setCount((prev) => Math.max(0, prev - 1))
  }

  // Set up the MutationObserver
  useEffect(() => {
    if (!sourceRef.current || !targetRef.current) return

    // Create a new MutationObserver instance
    const observer = new MutationObserver((mutations) => {
      // For each mutation
      mutations.forEach((mutation) => {
        // If the mutation is a change to the text content
        if (mutation.type === "childList" && sourceRef.current && targetRef.current) {
          // Update the target div with the source div's content
          targetRef.current.textContent = sourceRef.current.textContent
        }
      })
    })

    // Configure the observer to watch for changes to the source div's children
    const config = { childList: true, subtree: true }

    // Start observing the source div
    observer.observe(sourceRef.current, config)

    // Clean up the observer when the component unmounts
    return () => {
      observer.disconnect()
    }
  }, [])

  // Update the source div when the count changes
  useEffect(() => {
    if (sourceRef.current) {
      sourceRef.current.textContent = count.toString()
    }
  }, [count])

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 space-y-8">
      <h1 className="text-2xl font-bold">MutationObserver Demo</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-3xl">
        <Card className="p-6 space-y-4">
          <h2 className="text-xl font-semibold">Source Div</h2>
          <div className="flex justify-between items-center">
            <Button onClick={increment}>Increment (+1)</Button>
            <Button variant="destructive" onClick={decrement}>
              Decrement (-1)
            </Button>
          </div>

          {/* Source div that will be observed */}
          {count > 0 && (
            <div ref={sourceRef} className="mt-4 p-4 bg-gray-100 rounded-md text-center text-2xl font-bold">
              {count}
            </div>
          )}
        </Card>

        <Card className="p-6 space-y-4">
          <h2 className="text-xl font-semibold">Target Div (Updated via MutationObserver)</h2>

          {/* Target div that will be updated by the MutationObserver */}
          <div ref={targetRef} className="mt-4 p-4 bg-green-100 rounded-md text-center text-2xl font-bold min-h-[64px]">
            {count > 0 ? count : "Source div is hidden"}
          </div>
        </Card>
      </div>

      <div className="text-sm text-gray-500 max-w-3xl">
        <p>How it works:</p>
        <ol className="list-decimal list-inside space-y-1 mt-2">
          <li>Click the Increment button to increase the number in the source div</li>
          <li>The MutationObserver detects the change and updates the target div</li>
          <li>Click the Decrement button to decrease the number</li>
          <li>When the number reaches 0, the source div disappears</li>
        </ol>
      </div>
    </div>
  )
}
